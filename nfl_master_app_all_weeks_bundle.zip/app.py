
import streamlit as st
import pandas as pd
import re
from pathlib import Path

st.set_page_config(page_title="NFL Picks Tracker (Master + Season Tracker)", layout="wide")
st.title("🏈 NFL Picks Tracker — Master Schedule + Picks + Season Tracker")

DATA_DIR = Path("data")
MASTER_SCHEDULE = DATA_DIR / "nfl_2025_master_schedule.csv"

st.sidebar.header("Controls")

# Upload override for schedule (optional)
upl = st.sidebar.file_uploader("Upload full-season schedule CSV (optional)", type=["csv"])
if upl is not None:
    master_df = pd.read_csv(upl)
    st.sidebar.success(f"Loaded uploaded schedule: {upl.name} ({len(master_df)} rows)")
else:
    if MASTER_SCHEDULE.exists():
        master_df = pd.read_csv(MASTER_SCHEDULE)
        st.sidebar.info(f"Using {MASTER_SCHEDULE.name} ({len(master_df)} rows)")
    else:
        st.error("Full-season schedule file not found.\n\nExpected: data/nfl_2025_master_schedule.csv\n\nUpload a CSV or add it to the repo.")
        st.stop()

# Normalize schedule columns
master_df.columns = [c.strip().lower().replace(" ", "_") for c in master_df.columns]

def pick_col(df, options, contains=None):
    for c in df.columns:
        if c in options:
            return c
    if contains:
        for c in df.columns:
            if contains in c:
                return c
    return None

week_col = pick_col(master_df, ["week","wk"], contains="week")
away_col = pick_col(master_df, ["away_team","away","visitor","visiting"], contains="away")
home_col = pick_col(master_df, ["home_team","home","home_team_name"], contains="home")
date_col = pick_col(master_df, ["date","game_date"], contains="date")
time_col = pick_col(master_df, ["time","game_time","gametime","kickoff_time"], contains="time")
iso_col  = pick_col(master_df, ["kickoff_iso","kickoff_datetime","datetime","kickoff"], contains="datetime")

if week_col is None or away_col is None or home_col is None:
    st.error("Couldn't find required columns in schedule. Need at minimum: Week, Away Team, Home Team.")
    st.stop()

# -------- Schedule View --------
weeks = sorted(pd.unique(master_df[week_col]))
def format_week_label(w): 
    try: return f"Week {int(w)}"
    except: return f"Week {w}"

wk_idx = st.sidebar.selectbox("Select Week", list(range(len(weeks))), format_func=lambda i: format_week_label(weeks[i]))
selected_week = weeks[wk_idx]
wdf = master_df[master_df[week_col] == selected_week].copy()

disp = pd.DataFrame({
    "Week": wdf[week_col].astype(str),
    "Away Team": wdf[away_col].astype(str),
    "Home Team": wdf[home_col].astype(str),
})
if date_col:
    disp["Date"] = wdf[date_col].astype(str)
if time_col:
    disp["Time"] = wdf[time_col].astype(str)
if iso_col:
    dt = pd.to_datetime(wdf[iso_col], errors="coerce")
    disp["Kickoff ISO"] = dt.dt.strftime("%Y-%m-%d %H:%M").fillna(wdf[iso_col].astype(str))

st.subheader(f"📅 {format_week_label(selected_week)} Schedule")
st.dataframe(disp, use_container_width=True)

st.markdown("---")

# -------- Picks View (from CSVs) --------
st.sidebar.markdown("---")
st.sidebar.header("Picks Files (per-week)")
st.sidebar.code("data/week<week>_original_picks.csv\ndata/week<week>_adjusted_picks.csv", language="text")

def load_week_csv(prefix, week_value):
    wk_num = int(week_value) if str(week_value).isdigit() else week_value
    fname = f"week{wk_num}_{prefix}.csv"
    path = DATA_DIR / fname
    if path.exists():
        return pd.read_csv(path)
    return None

original_df = load_week_csv("original_picks", selected_week)
adjusted_df = load_week_csv("adjusted_picks", selected_week)

left, right = st.columns(2)
with left:
    st.subheader("📋 Original Picks")
    if original_df is None or original_df.empty:
        st.info("No original picks CSV found for this week.\nExpected: data/weekX_original_picks.csv")
    else:
        st.dataframe(original_df, use_container_width=True)

with right:
    st.subheader("🛡️ Adjusted Picks (Guardrails)")
    if adjusted_df is None or adjusted_df.empty:
        st.info("No adjusted picks CSV found for this week.\nExpected: data/weekX_adjusted_picks.csv")
    else:
        st.dataframe(adjusted_df, use_container_width=True)

# -------- What Changed? --------
st.markdown("---")
st.subheader("🔎 What Changed? (Original vs Adjusted)")
if original_df is not None and adjusted_df is not None and not original_df.empty and not adjusted_df.empty:
    try:
        comp = original_df.merge(adjusted_df, on=["Week","Matchup"], how="inner", suffixes=("_orig","_adj"))
        changed = comp[ (comp["Original ML"] != comp["Adjusted ML"]) | (comp["Original ATS"] != comp["Adjusted ATS"]) ]
        if changed.empty:
            st.info("No differences found between Original and Adjusted for this week.")
        else:
            st.dataframe(changed[["Week","Matchup","Original ML","Adjusted ML","Original ATS","Adjusted ATS","Guardrail Note"]], use_container_width=True)
    except Exception as e:
        st.warning(f"Couldn't compute diff: {e}")
else:
    st.info("Upload/add both original and adjusted picks CSVs for this week to see differences.")

# -------- Season Master Tracker (auto from all CSVs) --------
st.markdown("---")
st.subheader("📈 Season Master Tracker (Aggregated from CSVs)")

def list_weeks_from_files():
    # Find files like week3_original_picks.csv, week3_adjusted_picks.csv
    originals = sorted(DATA_DIR.glob("week*_original_picks.csv"))
    adjusted = sorted(DATA_DIR.glob("week*_adjusted_picks.csv"))
    # Extract week numbers that exist in BOTH original and adjusted
    def wknum(p): 
        m = re.search(r"week(\d+)_", p.name)
        return int(m.group(1)) if m else None
    weeks_o = set(filter(None, (wknum(p) for p in originals)))
    weeks_a = set(filter(None, (wknum(p) for p in adjusted)))
    return sorted(weeks_o & weeks_a)

def tally_results(df, ml_col="ML Result", ats_col="ATS Result"):
    # Count ✅ as win, ❌ as loss, everything else as pending/ignore
    def count_col(series):
        wins = (series.astype(str).str.strip() == "✅").sum()
        losses = (series.astype(str).str.strip() == "❌").sum()
        pending = len(series) - wins - losses
        return wins, losses, pending
    ml_w, ml_l, ml_p = count_col(df.get(ml_col, pd.Series(dtype=str)))
    ats_w, ats_l, ats_p = count_col(df.get(ats_col, pd.Series(dtype=str)))
    return (ml_w, ml_l, ml_p), (ats_w, ats_l, ats_p)

weeks_available = list_weeks_from_files()
if not weeks_available:
    st.info("No weekly picks files found yet. Add files like `data/week3_original_picks.csv` and `data/week3_adjusted_picks.csv`.")
else:
    rows = []
    tot_orig_ml = tot_orig_ats = tot_adj_ml = tot_adj_ats = (0,0,0)

    for w in weeks_available:
        o = pd.read_csv(DATA_DIR / f"week{w}_original_picks.csv")
        a = pd.read_csv(DATA_DIR / f"week{w}_adjusted_picks.csv")

        (o_ml_w, o_ml_l, o_ml_p), (o_ats_w, o_ats_l, o_ats_p) = tally_results(o)
        (a_ml_w, a_ml_l, a_ml_p), (a_ats_w, a_ats_l, a_ats_p) = tally_results(a)

        rows.append([f"Week {w}", f"{o_ml_w}-{o_ml_l}" + (" (pending)" if o_ml_p else ""),
                               f"{a_ml_w}-{a_ml_l}" + (" (pending)" if a_ml_p else ""),
                               f"{o_ats_w}-{o_ats_l}" + (" (pending)" if o_ats_p else ""),
                               f"{a_ats_w}-{a_ats_l}" + (" (pending)" if a_ats_p else "")])

        tot_orig_ml = (tot_orig_ml[0]+o_ml_w, tot_orig_ml[1]+o_ml_l, tot_orig_ml[2]+o_ml_p)
        tot_adj_ml  = (tot_adj_ml[0]+a_ml_w,  tot_adj_ml[1]+a_ml_l,  tot_adj_ml[2]+a_ml_p)
        tot_orig_ats= (tot_orig_ats[0]+o_ats_w,tot_orig_ats[1]+o_ats_l,tot_orig_ats[2]+o_ats_p)
        tot_adj_ats = (tot_adj_ats[0]+a_ats_w, tot_adj_ats[1]+a_ats_l, tot_adj_ats[2]+a_ats_p)

    # Totals
    rows.append(["Season-to-Date",
                 f"{tot_orig_ml[0]}-{tot_orig_ml[1]}" + (" (pending)" if tot_orig_ml[2] else ""),
                 f"{tot_adj_ml[0]}-{tot_adj_ml[1]}" + (" (pending)" if tot_adj_ml[2] else ""),
                 f"{tot_orig_ats[0]}-{tot_orig_ats[1]}" + (" (pending)" if tot_orig_ats[2] else ""),
                 f"{tot_adj_ats[0]}-{tot_adj_ats[1]}" + (" (pending)" if tot_adj_ats[2] else "")])

    season_df = pd.DataFrame(rows, columns=["Week","Original ML","Adjusted ML","Original ATS","Adjusted ATS (Selective)"])
    st.dataframe(season_df, use_container_width=True)

st.caption("Tip: drop weekly picks CSVs into /data and the Season Master Tracker will aggregate them automatically.")
